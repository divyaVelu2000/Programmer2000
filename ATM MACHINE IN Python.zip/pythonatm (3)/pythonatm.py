from datetime import date
from datetime import datetime
import random
import functools
import smtplib
from tkinter import *
import sqlite3
import sqlalchemy
from sqlalchemy import * 
from tkinter import *
import tkinter.messagebox
from PIL import Image,ImageTk
import pandas as pd

global value
class nextpagewindow:
    def __init__(self,window2,pin,Name):
        self.window2=window2
        self.pin=pin
        self.Name=Name
        self.window2.title("ATM")
        self.window2.geometry('1339x840') 

        frame1=Frame(self.window2,bd=4,relief=RIDGE,bg="salmon")
        frame1.place(x=280,y=100,width=800,height=500)

        frame2=Frame(frame1,width=500,height=400,bd=12,padx=20,relief=RIDGE,bg="wheat")
        frame2.grid(row=3,padx=140,pady=30)

        frame3=Frame(frame1,width=700,height=400,bd=16,relief=RIDGE,bg="wheat")
        frame3.place(x=190,y=150)

        label21 = Label(frame2, text = "CHOOSE YOUR OPTION", bg = "seashell",font=('aerial',15,'bold') )
        label21.pack(side='top',pady=10,padx=110) 

        def withdrawalprocess():
            newwindow=Toplevel(window2)
            newwindow.title("withdrawal")
            newwindow.geometry("1339x840") 
            self.bg=ImageTk.PhotoImage(file="ss.png")
            bg=Label(newwindow,image=self.bg).place(x=0,y=0,relwidth=1,relheight=1)

            frame1=Frame(newwindow,bg="turquoise1")
            frame1.place(x=50,y=75,width=400,height=500)

            self.label2=Label(frame1,text="Withdrawal Page",font=('arial',15,'bold'),bd=12,bg="maroon1",fg="black")
            self.label2.grid(row=2,column=0,pady=50,padx=90)

            amount=StringVar()

            self.label3=Label(frame1,text="Enter the amount",font=('arial',14,'bold'),bd=12,bg="maroon1",fg="black")
            self.label3.grid(row=4,column=0,pady=20,padx=50)

            self.firsttext=Entry(frame1,textvariable=amount,font=30,justify=RIGHT)
            self.firsttext.grid(row=5,columnspan=4,pady=10)

            def sendamtemail():
                
                amt=amount.get()
                acc_ba=StringVar()

                con=sqlite3.connect(r'C:/Users/Dell/divya.db')
                cur=con.cursor()
                cur.execute("select acc_bal from infotable where pin_no=?",(self.pin,))
                records=cur.fetchone()
                acc_ba.set(records)

                acc=acc_ba.get()
                
                cur.execute("select email from infotable where pin_no=?",(self.pin,))
                records=cur.fetchone()
                d=records[0]

                





                address_info = d
                name_info=self.Name
                
                SUBJECT="Amount Withdraw"
                email_body_info ="mr/miss/mrs."+name_info+" !the amount withdraw is Rs."+amt+"\nTotal amount in your account is Rs."+acc
                message = 'Subject: {}\n\n{}'.format(SUBJECT, email_body_info)
                print(address_info,email_body_info)
                #make sure to change security of your gmail account
                #Step1: click manage your account.STep2:Click security.Step3:go to less secure app access.Step4:make less secure apps to be on. 
                sender_email ="Enter your email id" 
                
                sender_password ="enter your password"
                
                server = smtplib.SMTP('smtp.gmail.com',587)
                
                server.starttls()
                
                server.login(sender_email,sender_password)
                
                print("Login successful")
                
                server.sendmail(sender_email,address_info,message)
                
                print("Message sent")
            

            def enter():

                con=sqlite3.connect(r'C:/Users/Dell/divya.db')
                cur=con.cursor()
                cur.execute("select acc_bal from infotable where pin_no=?",(self.pin,))
                records=cur.fetchone()
                res = functools.reduce(lambda sub, ele: sub * 10 + ele, records) 
                amt=int(amount.get())
                new_data=res-amt
                cur.execute("update infotable set acc_bal=? where pin_no=?",(new_data,self.pin))
                con.commit()
                sendamtemail()
                infoprocess()
                
            self.btncheck=Button(frame1,text="ENTER",bg="maroon1",fg="black",font=("arial",16,"bold"),padx=12,pady=12,bd=8,width=5,command=enter).grid(row=7,column=0)
 
        def depositprocess():
            newwindow1=Toplevel(window2)
            newwindow1.title("deposit")
            newwindow1.geometry("1339x840") 

            self.bg=ImageTk.PhotoImage(file="deposit.png")
            bg=Label(newwindow1,image=self.bg).place(x=0,y=0,relwidth=1,relheight=1)

            frame1=Frame(newwindow1,bg="maroon")
            frame1.place(x=900,y=75,width=400,height=500)

            self.label2=Label(frame1,text="DEPOSIT PAGE",font=('arial',15,'bold'),bd=12,bg="navajowhite",fg="black")
            self.label2.grid(row=2,column=0,pady=50,padx=90)

            amount=StringVar()

            self.label3=Label(frame1,text="Enter the amount",font=('arial',14,'bold'),bd=12,bg="navajowhite",fg="black")
            self.label3.grid(row=4,column=0,pady=20,padx=50)

            self.firsttext=Entry(frame1,textvariable=amount,font=30,justify=RIGHT)
            self.firsttext.grid(row=5,columnspan=4,pady=20)
            
            def sendamtemail():
                
                amt=amount.get()
                acc_ba=StringVar()

                con=sqlite3.connect(r'C:/Users/Dell/divya.db')
                cur=con.cursor()
                cur.execute("select acc_bal from infotable where pin_no=?",(self.pin,))
                records=cur.fetchone()
                acc_ba.set(records)

                acc=acc_ba.get()
                cur.execute("select email from infotable where pin_no=?",(self.pin,))
                records=cur.fetchone()
                print(records)
                d=records[0]

                address_info = d
                name_info=self.Name
                
                
                SUBJECT="Amount Deposit"
                email_body_info ="mr/miss/mrs."+name_info+" !the amount deposited is Rs."+amt+"\nTotal amount in your account is Rs."+acc
                message = 'Subject: {}\n\n{}'.format(SUBJECT, email_body_info)
                
                sender_email ="enter your email" 
                
                sender_password ="enter your password"
                
                server = smtplib.SMTP('smtp.gmail.com',587)
                
                server.starttls()
                
                server.login(sender_email,sender_password)
                
                print("Login successful")
                
                server.sendmail(sender_email,address_info,message)
                
                print("Message sent")
            



            def enter():

                con=sqlite3.connect(r'C:/Users/Dell/divya.db')
                cur=con.cursor()
                cur.execute("select acc_bal from infotable where pin_no=?",(self.pin,))
                records=cur.fetchone()
                res = functools.reduce(lambda sub, ele: sub * 10 + ele, records) 
                amt=int(amount.get())
                new_data=res+amt
                acc_balance=str(new_data)
                cur.execute("update infotable set acc_bal=? where pin_no=?",(new_data,self.pin))
                con.commit()
                sendamtemail()
                infoprocess()
              
            self.btncheck=Button(frame1,text="ENTER",bg="navajowhite",fg="black",font=("arial",16,"bold"),padx=12,pady=12,bd=8,width=5,command=enter).grid(row=7,column=0)
 
            
    
        def infoprocess():
            newwindow2=Toplevel(window2)
            newwindow2.title("balance_info")    
            newwindow2.geometry("1339x840") 
            
            self.bg=ImageTk.PhotoImage(file="ss.png")
            bg=Label(newwindow2,image=self.bg).place(x=0,y=0,relwidth=1,relheight=1)

            frame1=Frame(newwindow2,bg="chocolate")
            frame1.place(x=50,y=75,width=600,height=600)

            pin_no=StringVar()
            pin_no.set(self.pin)
            acc_ba=StringVar()
            con=sqlite3.connect(r'C:/Users/Dell/divya.db')
            cur=con.cursor()
            cur.execute("select acc_bal from infotable where pin_no=?",(self.pin,))
            records=cur.fetchone()
            acc_ba.set(records)
            Name=StringVar()
            Name.set(self.Name)

            title=Label(bg,text="welcome to info page",bg="rosybrown",fg="black")

            self.label2=Label(frame1,text="BALANCE INFORMATION",font=('arial',15,'bold'),bd=12,bg="bisque",fg="black")
            self.label2.grid(row=2,column=0,pady=50,padx=50)


            self.label3=Label(frame1,text="Enter Your Name",font=('arial',14,'bold'),bd=12,bg="bisque",fg="black")
            self.label3.grid(row=4,column=0,pady=20,padx=50)

            self.firsttext=Entry(frame1,textvariable=Name,font=30,justify=RIGHT)
            self.firsttext.grid(row=5,columnspan=4)

            self.label4=Label(frame1,text="Enter Your pin_no",font=('arial',14,'bold'),bd=12,bg="bisque",fg="black")
            self.label4.grid(row=6,column=0,pady=20,padx=50)

            self.firsttex=Entry(frame1,textvariable=pin_no,font=30,justify=RIGHT)
            self.firsttex.grid(row=7,columnspan=4)
            self.label5=Label(frame1,text="Your Balance",font=('arial',14,'bold'),bd=12,bg="bisque",fg="black")
            self.label5.grid(row=8,column=0,pady=20,padx=50)

            self.firstte=Entry(frame1,textvariable=acc_ba,font=30,justify=RIGHT)
            self.firstte.grid(row=9,columnspan=4)

            def enter():
                tkinter.messagebox.showinfo("Thank You","Thank You for Using ATM")



            self.btncheck=Button(frame1,text="Done",bg="bisque",fg="black",font=("arial",16,"bold"),padx=12,pady=12,bd=8,width=5,command=enter).grid(row=10,column=0,pady=20)
 
            

            
            con=sqlite3.connect(r'C:/Users/Dell/divya.db')
            cur=con.cursor()
            cur.execute("select acc_bal from infotable where pin_no=?",(self.pin,))
            records=cur.fetchone()
            acc_ba.set(records)

             
    
        def Pingeneration():
            newwindow3=Toplevel(window2)
            newwindow3.title("pingeneration")
            newwindow3.geometry("1339x840") 
            
            self.bg=ImageTk.PhotoImage(file="ss.png")
            bg=Label(newwindow3,image=self.bg).place(x=0,y=0,relwidth=1,relheight=1)

            frame1=Frame(newwindow3,bg="salmon")
            frame1.place(x=50,y=75,width=500,height=700)
            Name=StringVar()
            pin_no=StringVar()
            acc_ba=StringVar()


            title=Label(bg,text="welcome to Pin Generation page",bg="black",fg="skyblue")

            self.label2=Label(frame1,text="Pin Generation",font=('arial',13,'bold'),bd=12,bg="bisque",fg="black")
            self.label2.grid(row=2,column=0,pady=20,padx=50)


            self.label3=Label(frame1,text="Enter Your old Pin Number",font=('arial',14,'bold'),bd=12,bg="bisque",fg="black")
            self.label3.grid(row=4,column=0,pady=10,padx=50)

            self.firsttext=Entry(frame1,textvariable=Name,font=30,justify=RIGHT)
            self.firsttext.grid(row=5,columnspan=4,pady=10)

            self.label4=Label(frame1,text="Enter Otp",font=('arial',14,'bold'),bd=12,bg="bisque",fg="black")
            self.label4.grid(row=6,column=0,pady=10,padx=50)

            self.firsttex=Entry(frame1,textvariable=pin_no,font=30,justify=RIGHT)
            self.firsttex.grid(row=7,columnspan=4,padx=10,pady=10)

            
           
           
            
                
                
            def otp():
                y=str(x)
                con=sqlite3.connect(r'C:/Users/Dell/divya.db')
                cur=con.cursor()
                cur.execute("select email from infotable where pin_no=?",(self.pin,))
                records=cur.fetchone()
                d=records[0]

                
                address_info = d
                name_info=self.Name
                SUBJECT="OTP number "
                email_body_info ="mr/miss/mrs."+name_info+" !OTP number is"+y
                message = 'Subject: {}\n\n{}'.format(SUBJECT, email_body_info)
                

                
                print(address_info,email_body_info)
                
                sender_email ="enter your email" 
                
                sender_password ="enter your password"
                
                server = smtplib.SMTP('smtp.gmail.com',587)
                
                server.starttls()
                
                server.login(sender_email,sender_password)
                
                print("Login successful")
                
                server.sendmail(sender_email,address_info,message)
                
                print("Message sent")
       

            self.btncheck=Button(frame1,text="OTP",bg="Khaki",fg="black",font=("arial",13,"bold"),padx=12,pady=12,bd=8,width=5,command=otp).grid(row=7,column=5)

            self.label5=Label(frame1,text="Enter new pin_no",font=('arial',14,'bold'),bd=12,bg="bisque",fg="black")
            self.label5.grid(row=8,column=0,pady=20,padx=50)

            self.firstte=Entry(frame1,textvariable=acc_ba,font=30,justify=RIGHT)
            self.firstte.grid(row=9,columnspan=4,pady=10)

            def changepinemail():
                newpin1=acc_ba.get()
                con=sqlite3.connect(r'C:/Users/Dell/divya.db')
                cur=con.cursor()
                cur.execute("select email from infotable where pin_no=?",(self.pin,))
                records=cur.fetchone()
                d=records[0]
                print(records[0])
    
                address_info = d


                address_info = self.emailid
                name_info=self.Name
                SUBJECT="Regarding Pin Change"
                email_body_info ="mr/miss/mrs."+name_info+" !new Pin number is"+newpin1
                message = 'Subject: {}\n\n{}'.format(SUBJECT, email_body_info)
                
                
                
                sender_email ="enter your email" 
                
                sender_password ="enter your password"
                
                server = smtplib.SMTP('smtp.gmail.com',587)
                
                server.starttls()
                
                server.login(sender_email,sender_password)
                
                print("Login successful")
                
                server.sendmail(sender_email,address_info,message)
                
                print("Message sent")
            
            def enter1():
                newpin=int(acc_ba.get())
                oldpin=int(Name.get())
                a=pin_no.get()
                o=str(x)
                if a==o:
                
                    con=sqlite3.connect(r'C:/Users/Dell/divya.db')
                    cur=con.cursor()
                    cur.execute("update infotable set pin_no=? where pin_no=?",(newpin,oldpin))
                    con.commit()
                    self.pin=acc_ba.get()
                    changepinemail()
                    infoprocess()
                    

            self.btncheck1=Button(frame1,text="ENTER",bg="Khaki",fg="black",font=("arial",13,"bold"),padx=12,pady=12,bd=8,width=5,command=enter1).grid(row=10,column=0)
 
        button1 = Button(frame3, text = "WITHDRAWAL",borderwidth=10,font=('aerial',10,'bold'),bg='sandybrown',fg='black',command=withdrawalprocess) 
        button1.grid(row=0,column=0,pady=20,padx=30)
        button2 = Button(frame3, text = "BALANCE INFO",borderwidth=10,font=('aerial',10,'bold'),bg='sandybrown',fg='black',command=infoprocess) 
        button2.grid(row=0,column=2,pady=20,padx=30) 
        button3 = Button(frame3, text = "DEPOSIT AMT.",font=('aerial',10,'bold'),bg='sandybrown',fg='black',borderwidth=10,command=depositprocess) 
        button3.grid(row=4,column=0,pady=20,padx=30)
        button4 = Button(frame3, text = "PIN Generation",font=('aerial',10,'bold'),bg='sandybrown',fg='black',borderwidth=10,command=Pingeneration) 
        button4.grid(row=4,column=2,pady=20,padx=30)
        
        def database():
            con=sqlite3.connect(r'C:/Users/Dell/divya.db')
            cur=con.cursor()
            cur.execute("insert into infotable values('1234567899','bublu','2300')")
            con.commit()

class nextwindow:
    def __init__(self,window,firstnum):
        self.window=window
        self.firstnum=firstnum
        self.window.title("PROTECTION PAGE")
        self.window.geometry('1339x840')

        def send_message():
            con=sqlite3.connect(r'C:/Users/Dell/divya.db')
            cur=con.cursor()
            cur.execute("select email from infotable where pin_no=?",(pin_no.get(),))
            records=cur.fetchone()
            d=records[0]
            print(records[0])
    
            address_info = d
            name_info=name.get()
            SUBJECT = "Using of Atm card"
            email_body_info ="mr/miss/mrs."+name_info+" !you are using your card now"
            message = 'Subject: {}\n\n{}'.format(SUBJECT, email_body_info)
            
            
            
            print(address_info,message)
            
            sender_email ="enter your email" 
            
            sender_password ="enter your password"
            
            server = smtplib.SMTP('smtp.gmail.com',587)
            
            server.starttls()
            
            server.login(sender_email,sender_password)
            
            print("Login successful")
            
            server.sendmail(sender_email,address_info,message)
            
            print("Message sent")
            
            
    
    

        name=StringVar()
        email=StringVar()
        pin_no=StringVar()

        self.label3=Label(self.window,text="Details Page",font=('arial',20,'bold'),bd=12,fg="black",bg="gold")
        self.label3.place(x=900,y=20)

        frame1=Frame(self.window,bd=4,relief=RIDGE,bg="moccasin")
        frame1.place(x=700,y=100,width=600,height=550)

        frame2=Frame(frame1,width=800,height=400,bd=12,padx=20,relief=RIDGE,bg="darksalmon")
        frame2.grid(row=3,padx=150,pady=30)

        frame3=Frame(frame1,width=100,height=50,bd=16,padx=20,relief=RIDGE,bg="darksalmon")
        frame3.grid(row=4,padx=110,pady=20)

        self.label2=Label(frame2,text="Enter the Name in your card",font=('arial',14,'bold'),bd=12,bg="sandybrown",fg="black")
        self.label2.grid(row=0,column=0)

        self.firsttext=Entry(frame2,textvariable=name,bd=20,insertwidth=1,font=30,justify=RIGHT)
        self.firsttext.grid(row=1,columnspan=4)

        self.label1=Label(frame2,text="Enter your phoneno",font=('arial',14,'bold'),bd=12,bg="sandybrown",fg="black")
        self.label1.grid(row=2,column=0)

        self.secondtext=Entry(frame2,textvariable=email,bd=20,insertwidth=1,font=30,justify=RIGHT)
        self.secondtext.grid(row=3,columnspan=4)

        self.label1=Label(frame2,text="Enter your PIN NO.",font=('arial',14,'bold'),bd=12,bg="sandybrown",fg="black")
        self.label1.grid(row=4,column=0)

        self.secondtext=Entry(frame2,textvariable=pin_no,bd=20,insertwidth=1,font=30,justify=RIGHT,show="*")
        self.secondtext.grid(row=5,columnspan=4)

        def nextpage():
            
            Name=name.get()
            n=str(Name)
            Pin_no=pin_no.get()
            s=int(Pin_no)
            
            
            d=datetime.now()
            current_time = d.strftime("%H:%M:%S")
            c=str(current_time)
            today = date.today()
            d1 = today.strftime("%d/%m/%Y")
            da=str(d1)
            
            con=sqlite3.connect(r'C:/Users/Dell/divya.db')
            cur=con.cursor()
            cur.execute("insert into logins(Name,Date,Time,Pin_no)values(?,?,?,?)",(self.firstnum.get(),da,c,s,))
            con.commit()
            cur.execute("select * from infotable")
            records=cur.fetchall()
            flag=0
            for rows in records:
                if rows[0]==s and rows[1]==n:
                    flag=1
                    send_message()
                    window2=Toplevel(window)  
                    window2.title("divya")
                    window2.geometry("1339x840") 
                    ap=nextpagewindow(window2,Pin_no,Name)
            if flag==0:
                tkinter.messagebox.showwarning("warning","name or pin number is wrong")
            
            



        self.btncheck=Button(frame3,text="ENTER",bg="sandybrown",font=("arial",14,"bold"),padx=12,pady=10,bd=10,width=5,command=nextpage).grid(row=0,column=0)







class Atm:

    def __init__(self,root):
        self.root=root
        self.root.title("ATM")
        self.root.geometry('1339x840')  
       

        frame1=Frame(self.root,bd=4,relief=RIDGE,bg="Silver")
        frame1.place(x=720,y=100,width=600,height=550)

        frame2=Frame(frame1,width=300,height=200,bd=12,padx=20,relief=RIDGE,bg="Peru")
        frame2.grid(row=3,padx=110,pady=30)

        frame3=Frame(frame1,width=400,height=200,bd=16,padx=20,relief=RIDGE,bg="Peru")
        frame3.grid(row=4,padx=110,pady=30)

        firstnum=StringVar()
        num=StringVar()
        value=num

        self.label2=Label(frame2,text="Enter Username",font=('arial',14,'bold'),bd=12,bg="salmon",fg="black")
        self.label2.grid(row=0,column=0)

        self.firsttext=Entry(frame2,textvariable=firstnum,bd=20,insertwidth=1,font=30,justify=RIGHT)
        self.firsttext.grid(row=1,columnspan=4)

        self.label1=Label(frame2,text="Enter Number between 10-99",font=('arial',14,'bold'),bd=12,bg="salmon",fg="black")
        self.label1.grid(row=2,column=0)

        self.secondtext=Entry(frame2,textvariable=num,bd=20,insertwidth=1,font=30,justify=RIGHT)
        self.secondtext.grid(row=3,columnspan=4)


        def login1():
                  
            window=Toplevel(root)
            window.title("ATM")
            window.geometry("1339x840") 
            bg=PhotoImage(file="otp1.png")

            la = Label(window, image = bg) 
            la.place(x = 0,y = 0)
            
            
            app=nextwindow(window,firstnum)

            window.mainloop()

        def reset ():
            firstnum.set("")
            num.set("")

               


        self.btncheck=Button(frame3,text="ENTER",bg="salmon",font=("arial",16,"bold"),padx=12,pady=14,bd=12,width=8,command=login1).grid(row=0,column=0)
        self.btnreset=Button(frame3,text="RESET",bg="salmon",font=("arial",16,"bold"),padx=12,pady=14,bd=12,width=8,command=reset).grid(row=0,column=1)

        

if __name__ == "__main__":
    root=Tk()

    root.geometry('1339x840') 

    bg=PhotoImage(file="ATM.png")

    label11 = Label( root, image = bg) 
    label11.place(x = 0,y = 0)

    label22 = Label( root, text = "Welcome To ATM", bg = "#88cffa",font=('aerial',40,'bold') )
    label22.pack(side='top',pady=30)

    application=Atm(root)

    root.mainloop()
